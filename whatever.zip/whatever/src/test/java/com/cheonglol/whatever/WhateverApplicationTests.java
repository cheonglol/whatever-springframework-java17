package com.cheonglol.whatever;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WhateverApplicationTests {

	@Test
	void contextLoads() {
	}

}
